import tkinter as tk

def toggle_light():
    if light_status["text"] == "Light is OFF":
        light_status["text"] = "Light is ON"
    else:
        light_status["text"] = "Light is OFF"

app = tk.Tk()
app.title("Smart Room Light Controller")

light_status = tk.Label(app, text="Light is OFF", font=("Arial", 16))
light_status.pack(pady=10)

toggle_btn = tk.Button(app, text="Simulate Motion", command=toggle_light)
toggle_btn.pack(pady=10)

app.mainloop()

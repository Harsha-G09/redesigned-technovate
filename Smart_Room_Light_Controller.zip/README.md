# Smart Room Light Controller

A Python GUI app simulating motion-based light automation using Tkinter.